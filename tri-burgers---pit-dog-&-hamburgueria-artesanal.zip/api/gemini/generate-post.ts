import { GoogleGenAI } from "@google/genai";
import type { VercelRequest, VercelResponse } from '@vercel/node';
import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";
import crypto from 'crypto';

// Reutilizar lógica de descriptografia (deve ser idêntica ao api/server.ts)
const ENCRYPTION_KEY = process.env.SERVER_ENCRYPTION_KEY || 'default-secret-key-32-chars-long-!!!';
const DATABASE_ID = "ai-studio-e7104e09-5d7d-4fb2-be51-883f71432273";

function decrypt(text: string) {
  try {
    const textParts = text.split(':');
    if (textParts.length < 2) return null;
    const iv = Buffer.from(textParts.shift()!, 'hex');
    const encryptedText = Buffer.from(textParts.join(':'), 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY.padEnd(32).substring(0, 32)), iv);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted.toString();
  } catch (err) {
    return null;
  }
}

// Inicializar Admin se necessário (Vercel scope)
if (!admin.apps.length && process.env.FIREBASE_SERVICE_ACCOUNT) {
  try {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
    if (serviceAccount.private_key) {
      serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
    }
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount)
    });
  } catch (e) {
    console.error("Firebase Init Error inside API route:", e);
  }
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Método não permitido." });
  }

  try {
    let apiKey = process.env.GEMINI_API_KEY;

    // Tentar buscar chave do cliente no Firestore (Prioridade)
    try {
      const db = getFirestore(DATABASE_ID);
      const settingsDoc = await db.collection("settings").doc("gemini").get();
      if (settingsDoc.exists) {
        const encrypted = settingsDoc.data()?.encryptedKey;
        if (encrypted) {
          const decrypted = decrypt(encrypted);
          if (decrypted) apiKey = decrypted;
        }
      }
    } catch (dbErr) {
      console.warn("Falha ao ler chave do Firestore, usando fallback ENV se existir.");
    }

    if (!apiKey) {
      return res.status(400).json({ 
        error: "Configuração ausente",
        message: "Chave Gemini não encontrada. Por favor, configure sua chave nas configurações do painel." 
      });
    }

    const { product, shareLink } = req.body;
    const ai = new GoogleGenAI({ apiKey });
    
    const prompt = `
      Crie um post de marketing IRRESISTÍVEL para WhatsApp.
      Foque em DESEJO e FOMO (medo de ficar de fora).
      
      DADOS DO PRODUTO:
      Nome: ${product.name}
      Descrição: ${product.description}
      Preço: ${product.price}
      Categoria: ${product.category}
      
      ESTRUTURA:
      1. TÍTULO EM CAPS LOCK com emoji.
      2. 2 parágrafos curtos e persuasivos.
      3. Lista de ingredientes com ✅.
      4. Preço em destaque.
      5. Link da foto em linha isolada: ${shareLink}
      6. Call to Action forte.
      
      Regras: Use apenas emojis de comida/fogo. Formate para WhatsApp (*negrito*).
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt
    });

    const text = response.text;

    if (!text) throw new Error("IA retornou vazio");

    return res.status(200).json({ success: true, text });

  } catch (error: any) {
    console.error("Gemini API Error Detail:", error);
    
    let userMessage = "Erro ao gerar post. Verifique sua chave nas configurações.";
    let statusCode = 500;
    const errorString = String(error).toLowerCase();
    
    if (errorString.includes("429") || errorString.includes("quota")) {
      userMessage = "⚠️ Sua chave Gemini atingiu o limite de uso. Gere uma nova chave para continuar usando o gerador de posts. (Cota Excedida).";
      statusCode = 429;
    } else if (errorString.includes("401") || errorString.includes("403") || errorString.includes("invalid")) {
      userMessage = "Chave de API inválida ou expirada. Revise com atenção se realmente a chave salva está correta.";
      statusCode = 401;
    }

    return res.status(statusCode).json({
      error: "Erro na IA",
      message: userMessage
    });
  }
}
